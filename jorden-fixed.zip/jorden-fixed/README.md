# 🌐 Jorden — Website & Blog

A Jekyll-based website deployed on GitHub Pages. Includes a homepage, blog, and real estate marketing content.

## 🚀 Live Site
🔗 [jordanstephen.github.io/jorden](https://jordanstephen.github.io/jorden)

## 📁 Structure

```
jorden/
├── _includes/          # Shared partials (header, footer)
├── _layouts/           # Page templates (default, post)
├── _posts/             # Blog posts in Markdown
├── public/
│   └── images/         # All images and media
├── assets/
│   ├── css/main.css    # All shared styles
│   └── js/main.js      # JavaScript
├── index.html          # Homepage
├── blog.html           # Blog listing
├── real.html           # Real estate article
├── _config.yml         # Jekyll config
└── robots.txt          # SEO
```

## ⚙️ Local Setup

```bash
gem install bundler jekyll
jekyll serve
# Open http://localhost:4000
```

## ✍️ Adding a Blog Post

Create `_posts/YYYY-MM-DD-title.md`:

```yaml
---
layout: post
title: "Your Title"
date: 2025-05-14
---
Your content here...
```

## 🚀 Deploy

Push to `main` branch — GitHub Pages auto-deploys within 60 seconds.
